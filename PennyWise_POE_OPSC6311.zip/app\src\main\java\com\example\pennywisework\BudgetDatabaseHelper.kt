package com.example.pennywisework

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class BudgetDatabaseHelper(context: Context) : SQLiteOpenHelper(
    context,
    DATABASE_NAME,
    null,
    DATABASE_VERSION
) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                UNIQUE(user_id, name)
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE expenses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                category_id INTEGER NOT NULL,
                amount REAL NOT NULL,
                expense_date TEXT NOT NULL,
                start_time TEXT NOT NULL,
                end_time TEXT NOT NULL,
                description TEXT NOT NULL,
                photo_uri TEXT
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE goals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                month TEXT NOT NULL,
                min_goal REAL NOT NULL,
                max_goal REAL NOT NULL,
                UNIQUE(user_id, month)
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS goals")
        db.execSQL("DROP TABLE IF EXISTS expenses")
        db.execSQL("DROP TABLE IF EXISTS categories")
        db.execSQL("DROP TABLE IF EXISTS users")
        onCreate(db)
    }

    fun registerUser(username: String, password: String): UserSession? {
        return try {
            val db = writableDatabase
            val values = ContentValues().apply {
                put("username", username)
                put("password", password)
            }
            val id = db.insertOrThrow("users", null, values)
            if (id == -1L) null else UserSession(id.toInt(), username)
        } catch (_: Exception) {
            null
        }
    }

    fun loginUser(username: String, password: String): UserSession? {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT id, username FROM users WHERE username = ? AND password = ?",
            arrayOf(username, password)
        )

        cursor.use {
            return if (it.moveToFirst()) {
                UserSession(
                    id = it.getInt(0),
                    username = it.getString(1)
                )
            } else {
                null
            }
        }
    }

    fun getUserById(userId: Int): UserSession? {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT id, username FROM users WHERE id = ?",
            arrayOf(userId.toString())
        )

        cursor.use {
            return if (it.moveToFirst()) {
                UserSession(
                    id = it.getInt(0),
                    username = it.getString(1)
                )
            } else {
                null
            }
        }
    }

    fun addCategory(userId: Int, name: String): Boolean {
        return try {
            val db = writableDatabase
            val values = ContentValues().apply {
                put("user_id", userId)
                put("name", name)
            }
            db.insertOrThrow("categories", null, values) != -1L
        } catch (_: Exception) {
            false
        }
    }

    fun getOrCreateCategoryId(userId: Int, name: String): Int? {
        val trimmedName = name.trim()
        if (trimmedName.isEmpty()) return null

        val db = writableDatabase
        val existingCursor = db.rawQuery(
            "SELECT id FROM categories WHERE user_id = ? AND name = ? LIMIT 1",
            arrayOf(userId.toString(), trimmedName)
        )

        existingCursor.use {
            if (it.moveToFirst()) {
                return it.getInt(0)
            }
        }

        addCategory(userId, trimmedName)

        val createdCursor = db.rawQuery(
            "SELECT id FROM categories WHERE user_id = ? AND name = ? LIMIT 1",
            arrayOf(userId.toString(), trimmedName)
        )

        createdCursor.use {
            return if (it.moveToFirst()) it.getInt(0) else null
        }
    }

    fun getCategories(userId: Int): List<Category> {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT id, user_id, name FROM categories WHERE user_id = ? ORDER BY name ASC",
            arrayOf(userId.toString())
        )

        cursor.use {
            val categories = mutableListOf<Category>()
            while (it.moveToNext()) {
                categories.add(
                    Category(
                        id = it.getInt(0),
                        userId = it.getInt(1),
                        name = it.getString(2)
                    )
                )
            }
            return categories
        }
    }

    fun addExpense(
        userId: Int,
        categoryId: Int,
        amount: Double,
        date: String,
        startTime: String,
        endTime: String,
        description: String,
        photoUri: String?
    ): Boolean {
        return try {
            val db = writableDatabase
            val values = ContentValues().apply {
                put("user_id", userId)
                put("category_id", categoryId)
                put("amount", amount)
                put("expense_date", date)
                put("start_time", startTime)
                put("end_time", endTime)
                put("description", description)
                put("photo_uri", photoUri)
            }
            db.insertOrThrow("expenses", null, values) != -1L
        } catch (_: Exception) {
            false
        }
    }

    fun getExpenses(userId: Int, startDate: String, endDate: String): List<ExpenseRecord> {
        val db = readableDatabase
        val cursor = db.rawQuery(
            """
            SELECT e.id, e.category_id, c.name, e.amount, e.expense_date, e.start_time, e.end_time,
                   e.description, e.photo_uri
            FROM expenses e
            INNER JOIN categories c ON e.category_id = c.id
            WHERE e.user_id = ? AND e.expense_date BETWEEN ? AND ?
            ORDER BY e.expense_date DESC, e.start_time DESC
            """.trimIndent(),
            arrayOf(userId.toString(), startDate, endDate)
        )

        cursor.use {
            val expenses = mutableListOf<ExpenseRecord>()
            while (it.moveToNext()) {
                expenses.add(
                    ExpenseRecord(
                        id = it.getInt(0),
                        categoryId = it.getInt(1),
                        categoryName = it.getString(2),
                        amount = it.getDouble(3),
                        date = it.getString(4),
                        startTime = it.getString(5),
                        endTime = it.getString(6),
                        description = it.getString(7),
                        photoUri = it.getString(8)
                    )
                )
            }
            return expenses
        }
    }

    fun saveMonthlyGoal(userId: Int, month: String, minGoal: Double, maxGoal: Double) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("user_id", userId)
            put("month", month)
            put("min_goal", minGoal)
            put("max_goal", maxGoal)
        }
        db.insertWithOnConflict("goals", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun getMonthlyGoal(userId: Int, month: String): MonthlyGoal? {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT month, min_goal, max_goal FROM goals WHERE user_id = ? AND month = ?",
            arrayOf(userId.toString(), month)
        )

        cursor.use {
            return if (it.moveToFirst()) {
                MonthlyGoal(
                    month = it.getString(0),
                    minGoal = it.getDouble(1),
                    maxGoal = it.getDouble(2)
                )
            } else {
                null
            }
        }
    }

    fun getCategoryTotals(userId: Int, startDate: String, endDate: String): List<CategoryTotal> {
        val db = readableDatabase
        val cursor = db.rawQuery(
            """
            SELECT c.name, COALESCE(SUM(e.amount), 0)
            FROM expenses e
            INNER JOIN categories c ON e.category_id = c.id
            WHERE e.user_id = ? AND e.expense_date BETWEEN ? AND ?
            GROUP BY c.name
            ORDER BY c.name ASC
            """.trimIndent(),
            arrayOf(userId.toString(), startDate, endDate)
        )

        cursor.use {
            val totals = mutableListOf<CategoryTotal>()
            while (it.moveToNext()) {
                totals.add(
                    CategoryTotal(
                        categoryName = it.getString(0),
                        totalAmount = it.getDouble(1)
                    )
                )
            }
            return totals
        }
    }

    fun getMonthSpent(userId: Int, month: String): Double {
        val startDate = "$month-01"
        val endDate = "$month-31"
        val db = readableDatabase
        val cursor = db.rawQuery(
            """
            SELECT COALESCE(SUM(amount), 0)
            FROM expenses
            WHERE user_id = ? AND expense_date BETWEEN ? AND ?
            """.trimIndent(),
            arrayOf(userId.toString(), startDate, endDate)
        )

        cursor.use {
            return if (it.moveToFirst()) it.getDouble(0) else 0.0
        }
    }

    companion object {
        private const val DATABASE_NAME = "budget_tracker.db"
        private const val DATABASE_VERSION = 1
    }
}
