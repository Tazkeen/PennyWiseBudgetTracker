package com.example.pennywisework.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColorScheme = lightColorScheme(
    primary = PennyPrimary,
    secondary = PennySecondary,
    tertiary = PennyTertiary,
    background = PennyBackground,
    surface = PennySurface,
    surfaceVariant = PennySurfaceVariant,
    onPrimary = PennyOnPrimary,
    onSurface = PennyOnSurface,
    onBackground = PennyOnBackground
)

@Composable
fun PennywiseWorkTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography,
        content = content
    )
}
