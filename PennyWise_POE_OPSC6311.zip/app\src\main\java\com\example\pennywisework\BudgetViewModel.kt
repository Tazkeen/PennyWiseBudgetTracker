package com.example.pennywisework

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class BudgetViewModel(application: Application) : AndroidViewModel(application) {

    private val db = BudgetDatabaseHelper(application)
    private val prefs = application.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE)

    var currentUser by mutableStateOf<UserSession?>(null)
        private set

    var categories by mutableStateOf<List<Category>>(emptyList())
        private set

    var expenses by mutableStateOf<List<ExpenseRecord>>(emptyList())
        private set

    var totals by mutableStateOf<List<CategoryTotal>>(emptyList())
        private set

    var monthlyGoal by mutableStateOf<MonthlyGoal?>(null)
        private set

    var monthSpent by mutableDoubleStateOf(0.0)
        private set

    var notificationsEnabled by mutableStateOf(false)
        private set

    init {
        notificationsEnabled = prefs.getBoolean(KEY_NOTIFICATIONS_ENABLED, false)
        NotificationHelper.ensureChannel(application)
        restoreSession()
    }

    private fun restoreSession() {
        val savedUserId = prefs.getInt(KEY_USER_ID, -1)
        if (savedUserId != -1) {
            viewModelScope.launch {
                val user = withContext(Dispatchers.IO) { db.getUserById(savedUserId) }
                currentUser = user
                if (user != null) {
                    NotificationHelper.scheduleDailyReminder(getApplication(), notificationsEnabled)
                    ensureDefaultCategories(user.id)
                    refreshAll()
                }
            }
        }
    }

    fun register(username: String, password: String, onMessage: (String) -> Unit) {
        if (username.isBlank() || password.isBlank()) {
            onMessage("Enter both username and password.")
            return
        }

        viewModelScope.launch {
            val user = withContext(Dispatchers.IO) {
                db.registerUser(username.trim(), password.trim())
            }
            if (user == null) {
                onMessage("Username already exists.")
            } else {
                ensureDefaultCategories(user.id)
                setLoggedInUser(user)
                onMessage("Account created and logged in.")
            }
        }
    }

    fun login(username: String, password: String, onMessage: (String) -> Unit) {
        if (username.isBlank() || password.isBlank()) {
            onMessage("Enter both username and password.")
            return
        }

        viewModelScope.launch {
            val user = withContext(Dispatchers.IO) {
                db.loginUser(username.trim(), password.trim())
            }
            if (user == null) {
                onMessage("Invalid username or password.")
            } else {
                ensureDefaultCategories(user.id)
                setLoggedInUser(user)
                onMessage("Login successful.")
            }
        }
    }

    fun logout() {
        prefs.edit().remove(KEY_USER_ID).apply()
        NotificationHelper.scheduleDailyReminder(getApplication(), false)
        currentUser = null
        categories = emptyList()
        expenses = emptyList()
        totals = emptyList()
        monthlyGoal = null
        monthSpent = 0.0
    }

    fun addCategory(name: String, onMessage: (String) -> Unit) {
        val user = currentUser ?: return
        val trimmedName = name.trim()

        if (trimmedName.isEmpty()) {
            onMessage("Enter a category name.")
            return
        }

        viewModelScope.launch {
            val added = withContext(Dispatchers.IO) {
                db.addCategory(user.id, trimmedName)
            }
            if (added) {
                loadCategories()
                onMessage("Category saved.")
            } else {
                onMessage("Category already exists.")
            }
        }
    }

    fun addExpense(
        categoryId: Int?,
        categoryName: String?,
        amountText: String,
        date: String,
        startTime: String,
        endTime: String,
        description: String,
        photoUri: String?,
        onMessage: (String) -> Unit
    ) {
        val user = currentUser ?: return
        val amount = amountText.toDoubleOrNull()
        val trimmedCategoryName = categoryName?.trim().orEmpty()

        when {
            categoryId == null && trimmedCategoryName.isBlank() -> {
                onMessage("Choose a category.")
                return
            }
            amount == null || amount <= 0.0 -> {
                onMessage("Enter a valid amount.")
                return
            }
            date.isBlank() || startTime.isBlank() || endTime.isBlank() -> {
                onMessage("Enter date and times.")
                return
            }
            description.isBlank() -> {
                onMessage("Enter a description.")
                return
            }
        }

        viewModelScope.launch {
            val added = withContext(Dispatchers.IO) {
                val resolvedCategoryId = if (categoryId != null && categoryId > 0) {
                    categoryId
                } else {
                    db.getOrCreateCategoryId(user.id, trimmedCategoryName)
                }

                if (resolvedCategoryId == null) {
                    return@withContext false
                }

                db.addExpense(
                    userId = user.id,
                    categoryId = resolvedCategoryId,
                    amount = amount,
                    date = date,
                    startTime = startTime,
                    endTime = endTime,
                    description = description.trim(),
                    photoUri = photoUri
                )
            }
            if (added) {
                refreshAll()
                checkBudgetNotifications()
                onMessage("Expense saved.")
            } else {
                onMessage("Could not save expense.")
            }
        }
    }

    fun saveGoal(month: String, minGoalText: String, maxGoalText: String, onMessage: (String) -> Unit) {
        val user = currentUser ?: return
        val minGoal = minGoalText.toDoubleOrNull()
        val maxGoal = maxGoalText.toDoubleOrNull()

        when {
            month.isBlank() -> {
                onMessage("Enter a month in YYYY-MM format.")
                return
            }
            minGoal == null || maxGoal == null -> {
                onMessage("Enter valid minimum and maximum goals.")
                return
            }
            minGoal > maxGoal -> {
                onMessage("Minimum goal cannot be greater than maximum goal.")
                return
            }
        }

        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                db.saveMonthlyGoal(user.id, month, minGoal, maxGoal)
            }
            loadGoal(month)
            checkBudgetNotifications()
            onMessage("Monthly goal saved.")
        }
    }

    fun updateNotificationsEnabled(enabled: Boolean) {
        notificationsEnabled = enabled
        prefs.edit().putBoolean(KEY_NOTIFICATIONS_ENABLED, enabled).apply()
        NotificationHelper.scheduleDailyReminder(getApplication(), enabled && currentUser != null)
    }

    fun loadExpenses(startDate: String, endDate: String) {
        val user = currentUser ?: return
        viewModelScope.launch {
            expenses = withContext(Dispatchers.IO) {
                db.getExpenses(user.id, startDate, endDate)
            }
        }
    }

    fun loadTotals(startDate: String, endDate: String) {
        val user = currentUser ?: return
        viewModelScope.launch {
            totals = withContext(Dispatchers.IO) {
                db.getCategoryTotals(user.id, startDate, endDate)
            }
        }
    }

    fun loadGoal(month: String) {
        val user = currentUser ?: return
        viewModelScope.launch {
            monthlyGoal = withContext(Dispatchers.IO) {
                db.getMonthlyGoal(user.id, month)
            }
            monthSpent = withContext(Dispatchers.IO) {
                db.getMonthSpent(user.id, month)
            }
        }
    }

    fun refreshAll() {
        val month = currentMonth()
        val start = monthStart()
        val end = today()
        loadCategories()
        loadGoal(month)
        loadExpenses(start, end)
        loadTotals(start, end)
    }

    private fun loadCategories() {
        val user = currentUser ?: return
        viewModelScope.launch {
            categories = withContext(Dispatchers.IO) {
                val existing = db.getCategories(user.id)
                if (existing.isEmpty()) {
                    DEFAULT_CATEGORIES.forEach { name ->
                        db.addCategory(user.id, name)
                    }
                    db.getCategories(user.id)
                } else {
                    existing
                }
            }
        }
    }

    private fun setLoggedInUser(user: UserSession) {
        prefs.edit().putInt(KEY_USER_ID, user.id).apply()
        currentUser = user
        NotificationHelper.scheduleDailyReminder(getApplication(), notificationsEnabled)
        refreshAll()
    }

    private fun checkBudgetNotifications() {
        val user = currentUser ?: return
        if (!notificationsEnabled) return

        viewModelScope.launch {
            val month = currentMonth()
            val goal = withContext(Dispatchers.IO) {
                db.getMonthlyGoal(user.id, month)
            } ?: return@launch
            val spent = withContext(Dispatchers.IO) {
                db.getMonthSpent(user.id, month)
            }

            when {
                spent > goal.maxGoal -> NotificationHelper.showOverspending(getApplication(), spent, goal.maxGoal)
                goal.maxGoal > 0.0 && spent >= goal.maxGoal * BUDGET_WARNING_THRESHOLD -> {
                    NotificationHelper.showBudgetWarning(getApplication(), spent, goal.maxGoal)
                }
            }
        }
    }

    private suspend fun ensureDefaultCategories(userId: Int) {
        withContext(Dispatchers.IO) {
            DEFAULT_CATEGORIES.forEach { name ->
                db.addCategory(userId, name)
            }
        }
    }

    companion object {
        private const val SESSION_PREFS = "budget_session"
        private const val KEY_USER_ID = "logged_in_user_id"
        private const val KEY_NOTIFICATIONS_ENABLED = "notifications_enabled"
        private const val BUDGET_WARNING_THRESHOLD = 0.8
        private val DEFAULT_CATEGORIES = listOf(
            "Food & Dining",
            "Transportation",
            "Entertainment",
            "Bills & Utilities",
            "Health Care",
            "Shopping"
        )

        fun defaultCategoryNames(): List<String> = DEFAULT_CATEGORIES

        fun today(): String = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)

        fun monthStart(): String = LocalDate.now().withDayOfMonth(1)
            .format(DateTimeFormatter.ISO_LOCAL_DATE)

        fun currentMonth(): String = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM"))
    }
}
