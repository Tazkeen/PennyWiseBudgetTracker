package com.example.pennywisework

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.pennywisework.ui.theme.PennywiseWorkTheme
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter

private enum class AppSection(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Filled.Home),
    Expenses("Expenses", Icons.Filled.Add),
    Categories("Categories", Icons.Filled.Info),
    Budget("Budget", Icons.Filled.Home),
    Analytics("Analytics", Icons.Filled.Search),
    Achievements("Achievements", Icons.Filled.Info)
}

private val appSections = listOf(
    AppSection.Home,
    AppSection.Expenses,
    AppSection.Categories,
    AppSection.Budget,
    AppSection.Analytics,
    AppSection.Achievements
)

private val pageBackground = Color(0xFFF1F4FF)
private val panelBackground = Color(0xFFFFFFFF)
private val primaryInk = Color(0xFF05031A)
private val mutedText = Color(0xFF7F8498)
private val lavender = Color(0xFFEAE8FF)
private val accentBlue = Color(0xFF4A6CF7)
private val accentPurple = Color(0xFF9B4DFF)
private val accentOrange = Color(0xFFFF8A1E)
private val accentGreen = Color(0xFF16C05D)
private val accentRed = Color(0xFFFF5C77)
private val accentTeal = Color(0xFF3DC5D8)

class MainActivity : ComponentActivity() {
    private val viewModel: BudgetViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PennywiseWorkTheme {
                PennyWiseApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PennyWiseApp(viewModel: BudgetViewModel) {
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val currentUser = viewModel.currentUser
    val isCompact = isCompactScreen()
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.updateNotificationsEnabled(granted)
        if (!granted) {
            scope.launch {
                snackbarHostState.showSnackbar("Notification permission was denied.")
            }
        }
    }

    if (currentUser == null) {
        AuthFlow(
            onLogin = { username, password, onMessage ->
                viewModel.login(username, password, onMessage)
            },
            onRegister = { username, password, onMessage ->
                viewModel.register(username, password, onMessage)
            },
            snackbarHostState = snackbarHostState
        )
        return
    }

    val allCategories = mergeCategoryNames(viewModel.categories)
    var selectedSection by rememberSaveable { mutableStateOf(AppSection.Home) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LogoBadge(size = 36.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("PennyWise", color = primaryInk, fontWeight = FontWeight.SemiBold)
                    }
                },
                actions = {
                    if (!isCompact) {
                        Text(
                            text = "Welcome, ${currentUser.username}",
                            color = mutedText,
                            modifier = Modifier.padding(end = 12.dp)
                        )
                    }
                    Button(
                        onClick = { viewModel.logout() },
                        contentPadding = if (isCompact) {
                            PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        } else {
                            ButtonDefaults.ContentPadding
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = primaryInk
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Logout")
                    }
                }
            )
        },
        containerColor = pageBackground
    ) { innerPadding ->
        val contentModifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(if (isCompact) 10.dp else 16.dp)

        val onNotificationToggle: (Boolean) -> Unit = { enabled ->
            if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else if (enabled) {
                viewModel.updateNotificationsEnabled(true)
            } else {
                viewModel.updateNotificationsEnabled(false)
            }
        }

        if (isCompact) {
            Column(modifier = contentModifier) {
                CompactNavigation(
                    selectedSection = selectedSection,
                    onSelect = { selectedSection = it }
                )
                Spacer(modifier = Modifier.height(10.dp))
                AppContent(
                    selectedSection = selectedSection,
                    allCategories = allCategories,
                    currentUser = currentUser,
                    viewModel = viewModel,
                    scope = scope,
                    snackbarHostState = snackbarHostState,
                    modifier = Modifier.weight(1f),
                    onNotificationsEnabledChange = onNotificationToggle,
                    onNavigate = { selectedSection = it }
                )
            }
        } else {
            Row(
                modifier = contentModifier,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Sidebar(
                    selectedSection = selectedSection,
                    onSelect = { selectedSection = it },
                    modifier = Modifier.width(220.dp)
                )

                AppContent(
                    selectedSection = selectedSection,
                    allCategories = allCategories,
                    currentUser = currentUser,
                    viewModel = viewModel,
                    scope = scope,
                    snackbarHostState = snackbarHostState,
                    modifier = Modifier.weight(1f),
                    onNotificationsEnabledChange = onNotificationToggle,
                    onNavigate = { selectedSection = it }
                )
            }
        }
    }
}

@Composable
private fun AppContent(
    selectedSection: AppSection,
    allCategories: List<String>,
    currentUser: UserSession,
    viewModel: BudgetViewModel,
    scope: kotlinx.coroutines.CoroutineScope,
    snackbarHostState: SnackbarHostState,
    modifier: Modifier = Modifier,
    onNotificationsEnabledChange: (Boolean) -> Unit,
    onNavigate: (AppSection) -> Unit
) {
    when (selectedSection) {
        AppSection.Home -> HomeScreen(
            username = currentUser.username,
            monthSpent = viewModel.monthSpent,
            currentGoal = viewModel.monthlyGoal,
            categoriesCount = allCategories.size,
            expenses = viewModel.expenses,
            onNavigate = onNavigate,
            modifier = modifier
        )

        AppSection.Expenses -> ExpensesScreen(
            categories = allCategories,
            expenses = viewModel.expenses,
            onLoadExpenses = viewModel::loadExpenses,
            onSaveExpense = { categoryName, amount, date, startTime, endTime, description, photoUri ->
                viewModel.addExpense(
                    categoryId = null,
                    categoryName = categoryName,
                    amountText = amount,
                    date = date,
                    startTime = startTime,
                    endTime = endTime,
                    description = description,
                    photoUri = photoUri
                ) { message ->
                    scope.launch { snackbarHostState.showSnackbar(message) }
                }
            },
            modifier = modifier
        )

        AppSection.Categories -> CategoriesScreen(
            categories = allCategories,
            onAddCategory = { name ->
                viewModel.addCategory(name) { message ->
                    scope.launch { snackbarHostState.showSnackbar(message) }
                }
            },
            modifier = modifier
        )

        AppSection.Budget -> BudgetScreen(
            categories = allCategories,
            currentGoal = viewModel.monthlyGoal,
            monthSpent = viewModel.monthSpent,
            categoryTotals = viewModel.totals,
            notificationsEnabled = viewModel.notificationsEnabled,
            onNotificationsEnabledChange = onNotificationsEnabledChange,
            onSaveGoal = { month, minGoal, maxGoal ->
                viewModel.saveGoal(month, minGoal, maxGoal) { message ->
                    scope.launch { snackbarHostState.showSnackbar(message) }
                }
            },
            modifier = modifier
        )

        AppSection.Analytics -> AnalyticsScreen(
            totals = viewModel.totals,
            monthSpent = viewModel.monthSpent,
            expenses = viewModel.expenses,
            modifier = modifier
        )

        AppSection.Achievements -> AchievementsScreen(
            expenseCount = viewModel.expenses.size,
            monthSpent = viewModel.monthSpent,
            goal = viewModel.monthlyGoal,
            modifier = modifier
        )
    }
}

@Composable
private fun CompactNavigation(
    selectedSection: AppSection,
    onSelect: (AppSection) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        appSections.forEach { section ->
            val selected = section == selectedSection
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (selected) lavender else panelBackground)
                    .clickable { onSelect(section) }
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = section.icon,
                    contentDescription = section.label,
                    tint = if (selected) accentPurple else primaryInk,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = section.label,
                    color = if (selected) accentPurple else primaryInk,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun AuthFlow(
    onLogin: (String, String, (String) -> Unit) -> Unit,
    onRegister: (String, String, (String) -> Unit) -> Unit,
    snackbarHostState: SnackbarHostState
) {
    var isCreatingAccount by rememberSaveable { mutableStateOf(false) }
    var username by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var confirmPassword by rememberSaveable { mutableStateOf("") }
    var authMessage by rememberSaveable { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Scaffold(
        containerColor = Color.White,
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState()),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    LogoBadge(size = 92.dp)
                    Spacer(modifier = Modifier.height(18.dp))
                    Text(
                        text = if (isCreatingAccount) "Create Account" else "Welcome Back",
                        color = primaryInk,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (isCreatingAccount) {
                            "Get started with your expense tracking journey"
                        } else {
                            "Sign in to your expense tracker account"
                        },
                        color = mutedText,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(28.dp))
                    AuthField(
                        title = "Username",
                        value = username,
                        placeholder = if (isCreatingAccount) "Choose a username" else "Enter your username",
                        onValueChange = { username = it }
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    AuthField(
                        title = "Password",
                        value = password,
                        placeholder = if (isCreatingAccount) "Create a password" else "Enter your password",
                        onValueChange = { password = it },
                        password = true
                    )
                    if (isCreatingAccount) {
                        Spacer(modifier = Modifier.height(16.dp))
                        AuthField(
                            title = "Confirm Password",
                            value = confirmPassword,
                            placeholder = "Confirm your password",
                            onValueChange = { confirmPassword = it },
                            password = true
                        )
                    }
                    Spacer(modifier = Modifier.height(22.dp))
                    Button(
                        onClick = {
                            val showMessage: (String) -> Unit = { message ->
                                authMessage = message
                                scope.launch { snackbarHostState.showSnackbar(message) }
                            }
                            if (isCreatingAccount) {
                                if (password != confirmPassword) {
                                    showMessage("Passwords do not match.")
                                } else {
                                    onRegister(username, password, showMessage)
                                }
                            } else {
                                onLogin(username, password, showMessage)
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = primaryInk,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(if (isCreatingAccount) "Create Account" else "Sign In")
                    }
                    if (authMessage.isNotBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = authMessage,
                            color = if (authMessage.contains("successful", true) || authMessage.contains("created", true)) {
                                accentGreen
                            } else {
                                accentRed
                            },
                            textAlign = TextAlign.Center
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (isCreatingAccount) "Already have an account?" else "Don't have an account?",
                            color = mutedText
                        )
                        TextButton(onClick = {
                            isCreatingAccount = !isCreatingAccount
                            username = ""
                            password = ""
                            confirmPassword = ""
                            authMessage = ""
                        }) {
                            Text(
                                text = if (isCreatingAccount) "Sign in" else "Create one",
                                color = accentPurple,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Sidebar(
    selectedSection: AppSection,
    onSelect: (AppSection) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxHeight(),
        colors = CardDefaults.cardColors(containerColor = panelBackground),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            appSections.forEach { section ->
                val selected = section == selectedSection
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (selected) lavender else Color.Transparent)
                        .clickable { onSelect(section) }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = section.icon,
                        contentDescription = section.label,
                        tint = if (selected) accentPurple else primaryInk
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = section.label,
                        color = if (selected) accentPurple else primaryInk,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium
                    )
                }
            }
            Spacer(modifier = Modifier.weight(1f))
            Divider(color = Color(0xFFEDEEF4))
        }
    }
}

@Composable
private fun HomeScreen(
    username: String,
    monthSpent: Double,
    currentGoal: MonthlyGoal?,
    categoriesCount: Int,
    expenses: List<ExpenseRecord>,
    onNavigate: (AppSection) -> Unit,
    modifier: Modifier = Modifier
) {
    val budgetRemaining = ((currentGoal?.maxGoal ?: 0.0) - monthSpent).coerceAtLeast(0.0)
    val budgetStatus = when {
        currentGoal == null -> "No Goal"
        monthSpent > currentGoal.maxGoal -> "Over Budget"
        else -> "On Track"
    }

    PagePanel(
        modifier = modifier,
        title = "Dashboard",
        subtitle = "Welcome to your budget tracker. Here's an overview of your financial activity."
    ) {
        MetricGrid(
            items = listOf(
                MetricItem("Total Spent This Month", formatCurrency(monthSpent), Icons.Filled.Home, accentBlue),
                MetricItem("Budget Remaining", formatCurrency(budgetRemaining), Icons.Filled.Search, accentPurple),
                MetricItem("Active Categories", categoriesCount.toString(), Icons.Filled.Info, accentGreen),
                MetricItem("Budget Status", budgetStatus, Icons.Filled.Add, accentOrange)
            )
        )

        Spacer(modifier = Modifier.height(18.dp))
        SectionTitle("Quick Actions")
        Spacer(modifier = Modifier.height(12.dp))
        QuickActionsGrid(
            actions = listOf(
                QuickAction("Add Expense", "Record a new expense entry", accentBlue) { onNavigate(AppSection.Expenses) },
                QuickAction("Manage Categories", "Create and organize expense categories", accentPurple) { onNavigate(AppSection.Categories) },
                QuickAction("Set Budget", "Define your monthly budget goals", accentGreen) { onNavigate(AppSection.Budget) },
                QuickAction("View Analytics", "Track spending trends and insights", accentOrange) { onNavigate(AppSection.Analytics) }
            )
        )

        Spacer(modifier = Modifier.height(18.dp))
        SectionTitle("Recent Activity")
        DetailCard {
            if (expenses.isEmpty()) {
                EmptyPanel(
                    title = "No expenses recorded yet",
                    subtitle = "Add your first expense",
                    buttonLabel = "Add Your First Expense"
                ) { onNavigate(AppSection.Expenses) }
            } else {
                expenses.take(3).forEach { expense ->
                    ActivityRow(
                        title = expense.categoryName,
                        subtitle = "${expense.date}  ${expense.startTime}-${expense.endTime}",
                        value = formatCurrency(expense.amount)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))
        SectionTitle("Achievements")
        DetailCard {
            EmptyPanel(
                title = "Start tracking expenses to unlock achievements!",
                subtitle = "Track your progress and earn rewards",
                buttonLabel = "View All"
            ) { onNavigate(AppSection.Achievements) }
        }
    }
}

@Composable
private fun ExpensesScreen(
    categories: List<String>,
    expenses: List<ExpenseRecord>,
    onLoadExpenses: (String, String) -> Unit,
    onSaveExpense: (String, String, String, String, String, String, String?) -> Unit,
    modifier: Modifier = Modifier
) {
    var query by rememberSaveable { mutableStateOf("") }
    var selectedCategory by rememberSaveable { mutableStateOf("All Categories") }
    var menuExpanded by remember { mutableStateOf(false) }
    var showAddForm by rememberSaveable { mutableStateOf(false) }
    var amount by rememberSaveable { mutableStateOf("") }
    var date by rememberSaveable { mutableStateOf(BudgetViewModel.today()) }
    var startTime by rememberSaveable { mutableStateOf("08:00") }
    var endTime by rememberSaveable { mutableStateOf("09:00") }
    var categoryName by rememberSaveable { mutableStateOf(categories.firstOrNull() ?: BudgetViewModel.defaultCategoryNames().first()) }
    var description by rememberSaveable { mutableStateOf("") }
    var photoUri by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedExpenseId by rememberSaveable { mutableStateOf<Int?>(null) }
    val categoryOptions = listOf("All Categories") + categories
    val context = LocalContext.current
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) {
            }
            photoUri = uri.toString()
        }
    }

    LaunchedEffect(Unit) {
        onLoadExpenses(BudgetViewModel.monthStart(), BudgetViewModel.today())
    }

    val filteredExpenses = expenses.filter { expense ->
        val matchesCategory = selectedCategory == "All Categories" || expense.categoryName == selectedCategory
        val matchesQuery = query.isBlank() ||
            expense.categoryName.contains(query, true) ||
            expense.description.contains(query, true)
        matchesCategory && matchesQuery
    }
    val selectedExpense = filteredExpenses.firstOrNull { it.id == selectedExpenseId }
        ?: expenses.firstOrNull { it.id == selectedExpenseId }

    PagePanel(
        modifier = modifier,
        title = "Expenses",
        subtitle = "View, add, and manage your expense entries",
        action = {
            PrimaryDarkButton(
                label = if (showAddForm) "Close" else "Add Expense",
                icon = Icons.Filled.Add,
                onClick = { showAddForm = !showAddForm }
            )
        }
    ) {
        FilterBar(
            query = query,
            onQueryChange = { query = it },
            selectedOption = selectedCategory,
            options = categoryOptions,
            expanded = menuExpanded,
            onExpandedChange = { menuExpanded = it },
            onOptionSelected = {
                selectedCategory = it
                menuExpanded = false
            }
        )

        if (showAddForm) {
            Spacer(modifier = Modifier.height(16.dp))
            DetailCard {
                Text("Add Expense", fontWeight = FontWeight.SemiBold, color = primaryInk)
                Spacer(modifier = Modifier.height(12.dp))
                CleanTextField(amount, { amount = it }, "Amount")
                Spacer(modifier = Modifier.height(10.dp))
                DatePickerField("Date", date) { date = it }
                Spacer(modifier = Modifier.height(10.dp))
                TimePickerField("Start time", startTime) { startTime = it }
                Spacer(modifier = Modifier.height(10.dp))
                TimePickerField("End time", endTime) { endTime = it }
                Spacer(modifier = Modifier.height(10.dp))
                CleanTextField(categoryName, { categoryName = it }, "Category")
                if (categories.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    DropdownSelector(
                        label = "Choose Existing Category",
                        selectedValue = categoryName,
                        options = categories,
                        onSelected = { categoryName = it }
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                CleanTextField(description, { description = it }, "Description", minLines = 3)
                Spacer(modifier = Modifier.height(10.dp))
                PrimarySoftButton(
                    label = if (photoUri == null) "Add Photograph" else "Change Photograph",
                    icon = Icons.Filled.Add,
                    onClick = { photoPicker.launch(arrayOf("image/*")) }
                )
                if (photoUri != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    UriImage(photoUri)
                }
                Spacer(modifier = Modifier.height(12.dp))
                PrimaryDarkButton(label = "Save Expense", icon = Icons.Filled.Add, onClick = {
                    onSaveExpense(categoryName, amount, date, startTime, endTime, description, photoUri)
                    amount = ""
                    categoryName = categories.firstOrNull() ?: BudgetViewModel.defaultCategoryNames().first()
                    description = ""
                    photoUri = null
                    showAddForm = false
                })
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        DetailCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Total Expenses", color = mutedText)
                    Text(
                        formatCurrency(filteredExpenses.sumOf { it.amount }),
                        color = primaryInk,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Count", color = mutedText)
                    Text(
                        filteredExpenses.size.toString(),
                        color = primaryInk,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        if (selectedExpense != null) {
            Spacer(modifier = Modifier.height(16.dp))
            DetailCard {
                Text("Expense Details", color = primaryInk, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(14.dp))
                ActivityRow(
                    title = selectedExpense.categoryName,
                    subtitle = "${selectedExpense.date}  ${selectedExpense.startTime} - ${selectedExpense.endTime}",
                    value = formatCurrency(selectedExpense.amount)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text("Description", color = mutedText, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(selectedExpense.description, color = primaryInk)
                if (!selectedExpense.photoUri.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Attached Photo", color = mutedText, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    UriImage(selectedExpense.photoUri)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        DetailCard {
            Text("Expense History", color = primaryInk, fontWeight = FontWeight.SemiBold)
            Text("Tap any expense to view its details", color = mutedText)
            Spacer(modifier = Modifier.height(14.dp))
            if (filteredExpenses.isEmpty()) {
                EmptyPanel("No expenses found", "Add your first expense to get started", null, null)
            } else {
                filteredExpenses.forEach { expense ->
                    ActivityRow(
                        title = expense.categoryName,
                        subtitle = "${expense.date}  ${expense.description}",
                        value = formatCurrency(expense.amount),
                        onClick = { selectedExpenseId = expense.id }
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }
        }
    }
}

@Composable
private fun CategoriesScreen(
    categories: List<String>,
    onAddCategory: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var query by rememberSaveable { mutableStateOf("") }
    var newCategoryName by rememberSaveable { mutableStateOf("") }
    val filteredCategories = categories.filter { it.contains(query, true) }

    PagePanel(
        modifier = modifier,
        title = "Categories",
        subtitle = "Here are your current categories. You can create new categories to organize your expenses.",
        action = {
            SearchBox(query = query, onQueryChange = { query = it }, width = 200.dp)
        }
    ) {
        FlowGridLike(
            items = filteredCategories,
            itemContent = { category ->
                CategoryCard(category)
            },
            trailingContent = {
                AddCategoryCard(
                    categoryName = newCategoryName,
                    onCategoryNameChange = { newCategoryName = it },
                    onAdd = {
                        onAddCategory(newCategoryName)
                        newCategoryName = ""
                    }
                )
            }
        )
    }
}

@Composable
private fun BudgetScreen(
    categories: List<String>,
    currentGoal: MonthlyGoal?,
    monthSpent: Double,
    categoryTotals: List<CategoryTotal>,
    notificationsEnabled: Boolean,
    onNotificationsEnabledChange: (Boolean) -> Unit,
    onSaveGoal: (String, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var goalInput by rememberSaveable {
        mutableStateOf(currentGoal?.maxGoal?.toInt()?.toString() ?: "20000")
    }

    val budgetTotal = currentGoal?.maxGoal ?: goalInput.toDoubleOrNull() ?: 20000.0
    val progress = if (budgetTotal <= 0.0) 0f else (monthSpent / budgetTotal).toFloat().coerceIn(0f, 1f)
    val displayCategories = if (categories.isEmpty()) BudgetViewModel.defaultCategoryNames() else categories

    PagePanel(
        modifier = modifier,
        title = "Budget",
        subtitle = "Set your monthly total budget goal and allocate specific limits for each expense category."
    ) {
        NotificationSettingsCard(
            enabled = notificationsEnabled,
            monthSpent = monthSpent,
            goal = currentGoal,
            onEnabledChange = onNotificationsEnabledChange
        )

        Spacer(modifier = Modifier.height(16.dp))
        DetailCard {
            Text("Monthly Budget Goal", color = primaryInk, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(12.dp))
            CleanTextField(goalInput, { goalInput = it }, "Monthly Budget")
            Spacer(modifier = Modifier.height(12.dp))
            ProgressRow(
                leftText = formatCurrency(monthSpent),
                rightText = formatCurrency(budgetTotal),
                progress = progress,
                color = accentBlue
            )
            Spacer(modifier = Modifier.height(12.dp))
            PrimaryDarkButton(label = "Save Budget", icon = Icons.Filled.Add, onClick = {
                onSaveGoal(BudgetViewModel.currentMonth(), "0", goalInput)
            })
        }

        Spacer(modifier = Modifier.height(16.dp))
        FlowGridLike(
            items = displayCategories,
            itemContent = { category ->
                val total = categoryTotals.firstOrNull { it.categoryName == category }?.totalAmount ?: 0.0
                val limit = (budgetTotal / displayCategories.size.coerceAtLeast(1)).coerceAtLeast(1.0)
                BudgetCategoryCard(category, total, limit)
            }
        )
    }
}

@Composable
private fun AnalyticsScreen(
    totals: List<CategoryTotal>,
    monthSpent: Double,
    expenses: List<ExpenseRecord>,
    modifier: Modifier = Modifier
) {
    val isCompact = isCompactScreen()
    val displayTotals = totals.filter { it.totalAmount > 0.0 }
    val trendValues = expenseTrendValues(expenses)

    PagePanel(
        modifier = modifier,
        title = "Analytics",
        subtitle = "Insights into your spending habits and financial trends for this month."
    ) {
        if (isCompact) {
            DetailCard(modifier = Modifier.fillMaxWidth()) {
                Text("Spending Overview", fontWeight = FontWeight.SemiBold, color = primaryInk)
                Spacer(modifier = Modifier.height(16.dp))
                if (displayTotals.isEmpty()) {
                    EmptyPanel("No spending yet", "Add expenses to see your spending overview", null, null)
                } else {
                    DonutOverview(total = monthSpent, items = displayTotals)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            DetailCard(modifier = Modifier.fillMaxWidth()) {
                Text("Spending Trend", fontWeight = FontWeight.SemiBold, color = primaryInk)
                Spacer(modifier = Modifier.height(12.dp))
                if (trendValues.isEmpty()) {
                    EmptyPanel("No trend yet", "Your chart will update as you add expenses", null, null)
                } else {
                    TrendChart(
                        values = trendValues,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    )
                }
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
                DetailCard(modifier = Modifier.weight(1f)) {
                    Text("Spending Overview", fontWeight = FontWeight.SemiBold, color = primaryInk)
                    Spacer(modifier = Modifier.height(16.dp))
                    if (displayTotals.isEmpty()) {
                        EmptyPanel("No spending yet", "Add expenses to see your spending overview", null, null)
                    } else {
                        DonutOverview(total = monthSpent, items = displayTotals)
                    }
                }
                DetailCard(modifier = Modifier.weight(1f)) {
                    Text("Spending Trend", fontWeight = FontWeight.SemiBold, color = primaryInk)
                    Spacer(modifier = Modifier.height(12.dp))
                    if (trendValues.isEmpty()) {
                        EmptyPanel("No trend yet", "Your chart will update as you add expenses", null, null)
                    } else {
                        TrendChart(
                            values = trendValues,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        DetailCard {
            if (isCompact) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("Category Breakdown", fontWeight = FontWeight.SemiBold, color = primaryInk)
                    Text("Detailed spending analysis by category", color = mutedText)
                    Spacer(modifier = Modifier.height(12.dp))
                    PrimarySoftButton(label = "Export Report", icon = Icons.Filled.Info, compact = true, onClick = {})
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Category Breakdown", fontWeight = FontWeight.SemiBold, color = primaryInk)
                        Text("Detailed spending analysis by category", color = mutedText)
                    }
                    PrimarySoftButton(label = "Export Report", icon = Icons.Filled.Info, compact = true, onClick = {})
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
            if (displayTotals.isEmpty()) {
                EmptyPanel("No category data", "Add expenses to compare spending by category", null, null)
            } else {
                displayTotals.forEach { total ->
                    val limit = (displayTotals.sumOf { it.totalAmount } / displayTotals.size.coerceAtLeast(1)).coerceAtLeast(1.0)
                    AnalyticsCategoryRow(total.categoryName, total.totalAmount, limit)
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        DetailCard {
            Text("Monthly Insights", fontWeight = FontWeight.SemiBold, color = primaryInk)
            Spacer(modifier = Modifier.height(12.dp))
            if (expenses.isEmpty()) {
                EmptyPanel("No insights yet", "Log expenses to generate monthly insights", null, null)
            } else {
                Card(
                    colors = CardDefaults.cardColors(containerColor = lavender),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Info, contentDescription = null, tint = accentBlue)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Current month spending", fontWeight = FontWeight.SemiBold, color = primaryInk)
                            Text("You have logged ${expenses.size} expense${if (expenses.size == 1) "" else "s"} totaling ${formatCurrency(monthSpent)}.", color = mutedText)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AchievementsScreen(
    expenseCount: Int,
    monthSpent: Double,
    goal: MonthlyGoal?,
    modifier: Modifier = Modifier
) {
    val isCompact = isCompactScreen()
    val unlockedBudget = goal != null && monthSpent <= goal.maxGoal
    val hasExpenses = expenseCount > 0
    val achievementCards = listOf(
        AchievementCardData("Budget Master", "Meet your budget goals 3 times", unlockedBudget && hasExpenses, accentBlue),
        AchievementCardData("Super Saver", "Save 5 months in a row", false, accentOrange),
        AchievementCardData("Logging Streak", "Log expenses for 7 days in a row", expenseCount >= 7, accentRed),
        AchievementCardData("Financial Wizard", "Save and log expenses for 12 months", expenseCount >= 12, accentPurple),
        AchievementCardData("Habitual Logger", "Log expenses for 30 days in a row", expenseCount >= 30, accentTeal),
        AchievementCardData("Consistency Champ", "Log expenses every day for 3 months", expenseCount >= 90, accentGreen)
    )
    val unlockedCount = achievementCards.count { it.unlocked }

    PagePanel(
        modifier = modifier,
        title = "Achievements",
        subtitle = "Earn badges and rewards by meeting your budget goals and logging your expenses consistently."
    ) {
        FlowGridLike(
            items = achievementCards,
            itemContent = { item ->
                AchievementCard(item)
            }
        )

        Spacer(modifier = Modifier.height(16.dp))
        DetailCard {
            if (unlockedCount == 0) {
                EmptyPanel("No rewards earned yet", "Start logging expenses to unlock rewards", null, null)
            } else if (isCompact) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Info, contentDescription = null, tint = accentPurple, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Reward Earned!", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = primaryInk)
                            Text("Great job! You've earned a R200 gift card", color = mutedText)
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = lavender)) {
                        Text("R200 Gift Card", modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp), color = primaryInk)
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Info, contentDescription = null, tint = accentPurple, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Reward Earned!", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = primaryInk)
                            Text("Great job! You've earned a R200 gift card", color = mutedText)
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = lavender)) {
                        Text("R200 Gift Card", modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp), color = primaryInk)
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationSettingsCard(
    enabled: Boolean,
    monthSpent: Double,
    goal: MonthlyGoal?,
    onEnabledChange: (Boolean) -> Unit
) {
    val maxGoal = goal?.maxGoal ?: 0.0
    val budgetProgress = if (maxGoal <= 0.0) 0f else (monthSpent / maxGoal).toFloat().coerceIn(0f, 1f)
    val statusText = when {
        goal == null -> "Set a monthly budget to activate budget alerts."
        monthSpent > maxGoal -> "Overspending notifications are active."
        monthSpent >= maxGoal * 0.8 -> "Budget limit alerts are active."
        else -> "Budget alerts are ready."
    }
    val statusColor = when {
        goal == null -> mutedText
        monthSpent > maxGoal -> accentRed
        monthSpent >= maxGoal * 0.8 -> accentOrange
        else -> accentGreen
    }

    DetailCard {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    IconBubble(Icons.Filled.Info, if (enabled) accentGreen else mutedText)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Notifications", color = primaryInk, fontWeight = FontWeight.SemiBold, fontSize = 20.sp)
                }
                Switch(checked = enabled, onCheckedChange = onEnabledChange)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                if (enabled) "Alerts and reminders are active." else "Turn this on to enable alerts and reminders.",
                color = mutedText
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBubble(Icons.Filled.Info, statusColor)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Budget Alerts", color = primaryInk, fontWeight = FontWeight.SemiBold)
                Text(statusText, color = mutedText)
            }
        }
        if (goal != null) {
            Spacer(modifier = Modifier.height(14.dp))
            ProgressRow(
                leftText = formatCurrency(monthSpent),
                rightText = formatCurrency(maxGoal),
                progress = budgetProgress,
                color = statusColor
            )
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text("Daily reminder: 20:00. Budget warning: 80%. Overspending alert: when you pass your limit.", color = mutedText)
    }
}

@Composable
private fun AuthField(
    title: String,
    value: String,
    placeholder: String,
    onValueChange: (String) -> Unit,
    password: Boolean = false
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(title, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start, fontWeight = FontWeight.SemiBold, color = primaryInk)
        Spacer(modifier = Modifier.height(8.dp))
        TextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp),
            placeholder = { Text(placeholder, color = mutedText) },
            shape = RoundedCornerShape(10.dp),
            visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
            singleLine = true,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color(0xFFF3F3F6),
                unfocusedContainerColor = Color(0xFFF3F3F6),
                disabledContainerColor = Color(0xFFF3F3F6),
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                disabledIndicatorColor = Color.Transparent
            )
        )
    }
}

@Composable
private fun PagePanel(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    action: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val isCompact = isCompactScreen()
    Column(
        modifier = modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(22.dp))
            .background(pageBackground)
            .verticalScroll(rememberScrollState())
            .padding(if (isCompact) 14.dp else 20.dp)
    ) {
        if (isCompact) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(title, color = primaryInk, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                Text(subtitle, color = mutedText)
                if (action != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    action()
                }
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column {
                    Text(title, color = primaryInk, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(subtitle, color = mutedText)
                }
                action?.invoke()
            }
        }
        Spacer(modifier = Modifier.height(18.dp))
        content()
    }
}

@Composable
private fun MetricGrid(items: List<MetricItem>) {
    val isCompact = isCompactScreen()
    if (isCompact) {
        items.forEachIndexed { index, item ->
            MetricCard(item, Modifier.fillMaxWidth())
            if (index != items.lastIndex) {
                Spacer(modifier = Modifier.height(14.dp))
            }
        }
    } else {
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
            items.take(2).forEach { item ->
                MetricCard(item, Modifier.weight(1f))
            }
        }
        Spacer(modifier = Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
            items.drop(2).forEach { item ->
                MetricCard(item, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun MetricCard(item: MetricItem, modifier: Modifier = Modifier) {
    DetailCard(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(item.title, color = mutedText)
                Spacer(modifier = Modifier.height(8.dp))
                Text(item.value, color = primaryInk, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            }
            IconBubble(icon = item.icon, color = item.color)
        }
    }
}

@Composable
private fun QuickActionsGrid(actions: List<QuickAction>) {
    val isCompact = isCompactScreen()
    if (isCompact) {
        actions.forEachIndexed { index, action ->
            QuickActionCard(action, Modifier.fillMaxWidth())
            if (index != actions.lastIndex) {
                Spacer(modifier = Modifier.height(14.dp))
            }
        }
    } else {
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
            actions.take(2).forEach { action ->
                QuickActionCard(action, Modifier.weight(1f))
            }
        }
        Spacer(modifier = Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
            actions.drop(2).forEach { action ->
                QuickActionCard(action, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun QuickActionCard(action: QuickAction, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.clickable { action.onClick() },
        colors = CardDefaults.cardColors(containerColor = panelBackground),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(action.color),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, tint = Color.White)
            }
            Spacer(modifier = Modifier.height(22.dp))
            Text(action.title, color = primaryInk, fontWeight = FontWeight.SemiBold, fontSize = 20.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Text(action.subtitle, color = mutedText)
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = primaryInk, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun DetailCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = panelBackground),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp), content = content)
    }
}

@Composable
private fun EmptyPanel(
    title: String,
    subtitle: String,
    buttonLabel: String?,
    onButtonClick: (() -> Unit)?
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Filled.Info, contentDescription = null, tint = Color(0xFFD7D9E4), modifier = Modifier.size(42.dp))
        Spacer(modifier = Modifier.height(12.dp))
        Text(title, color = primaryInk)
        Text(subtitle, color = mutedText)
        if (buttonLabel != null && onButtonClick != null) {
            Spacer(modifier = Modifier.height(12.dp))
            PrimaryDarkButton(label = buttonLabel, icon = null, onClick = onButtonClick)
        }
    }
}

@Composable
private fun ActivityRow(
    title: String,
    subtitle: String,
    value: String,
    onClick: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(enabled = onClick != null) { onClick?.invoke() }
            .padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = primaryInk, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = mutedText)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Text(value, color = primaryInk, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun FilterBar(
    query: String,
    onQueryChange: (String) -> Unit,
    selectedOption: String,
    options: List<String>,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    onOptionSelected: (String) -> Unit
) {
    DetailCard {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            SearchBox(query, onQueryChange, modifier = Modifier.weight(1f))
            DropdownSelector(
                label = "Category",
                selectedValue = selectedOption,
                options = options,
                onSelected = onOptionSelected,
                modifier = Modifier.width(190.dp),
                expanded = expanded,
                onExpandedChange = onExpandedChange
            )
        }
    }
}

@Composable
private fun SearchBox(
    query: String,
    onQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    width: androidx.compose.ui.unit.Dp? = null
) {
    val finalModifier = if (width != null) modifier.width(width) else modifier
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = finalModifier,
        placeholder = { Text("Search...", color = mutedText) },
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = mutedText) },
        shape = RoundedCornerShape(14.dp)
    )
}

@Composable
private fun CategoryCard(name: String) {
    val (color, emoji, subtitle) = categoryVisuals(name)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(110.dp),
        colors = CardDefaults.cardColors(containerColor = panelBackground),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text(emoji, fontSize = 24.sp)
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(name, color = primaryInk, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = mutedText)
            }
        }
    }
}

@Composable
private fun AddCategoryCard(
    categoryName: String,
    onCategoryNameChange: (String) -> Unit,
    onAdd: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(190.dp),
        colors = CardDefaults.cardColors(containerColor = panelBackground),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            IconBubble(Icons.Filled.Add, accentPurple)
            Spacer(modifier = Modifier.height(12.dp))
            Text("Add New Category", color = primaryInk, fontWeight = FontWeight.SemiBold)
            Text("Create a custom category.", color = mutedText)
            Spacer(modifier = Modifier.height(12.dp))
            CleanTextField(
                value = categoryName,
                onValueChange = onCategoryNameChange,
                label = "Custom category name"
            )
            Spacer(modifier = Modifier.height(10.dp))
            PrimaryDarkButton(label = "Add", icon = Icons.Filled.Add, onClick = onAdd, compact = true)
        }
    }
}

@Composable
private fun BudgetCategoryCard(name: String, spent: Double, limit: Double) {
    val (color, emoji, _) = categoryVisuals(name)
    DetailCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(emoji, fontSize = 22.sp)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(name, color = primaryInk, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            }
            Text(formatCurrency(limit), color = mutedText)
        }
        Spacer(modifier = Modifier.height(10.dp))
        ProgressRow(
            leftText = formatCurrency(spent),
            rightText = formatCurrency(limit),
            progress = (spent / limit).toFloat().coerceIn(0f, 1f),
            color = color
        )
    }
}

@Composable
private fun DonutOverview(total: Double, items: List<CategoryTotal>) {
    val isCompact = isCompactScreen()
    Column(modifier = Modifier.fillMaxWidth()) {
        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.size(if (isCompact) 150.dp else 170.dp)) {
                val stroke = 18.dp.toPx()
                drawArc(
                    color = Color(0xFFE6E8F0),
                    startAngle = 135f,
                    sweepAngle = 270f,
                    useCenter = false,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke, cap = StrokeCap.Round)
                )
                drawArc(
                    color = accentBlue,
                    startAngle = 135f,
                    sweepAngle = 210f,
                    useCenter = false,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke, cap = StrokeCap.Round)
                )
            }
        }
        Spacer(modifier = Modifier.height(14.dp))
        Text(formatCurrency(total), color = primaryInk, fontWeight = FontWeight.SemiBold, fontSize = if (isCompact) 20.sp else 24.sp)
        Text("total spent", color = mutedText)
        Spacer(modifier = Modifier.height(12.dp))
        items.take(3).forEach { item ->
            val (color, _, _) = categoryVisuals(item.categoryName)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(color)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(item.categoryName, color = primaryInk)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(formatCurrency(item.totalAmount), color = primaryInk, fontWeight = FontWeight.SemiBold)
            }
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
private fun TrendChart(values: List<Float>, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val stepX = size.width / (values.size - 1).coerceAtLeast(1)
        val max = values.maxOrNull()?.coerceAtLeast(1f) ?: 1f
        for (index in 0 until values.lastIndex) {
            val start = Offset(stepX * index, size.height - (values[index] / max) * size.height * 0.8f)
            val end = Offset(stepX * (index + 1), size.height - (values[index + 1] / max) * size.height * 0.8f)
            drawLine(color = accentBlue, start = start, end = end, strokeWidth = 6f, cap = StrokeCap.Round)
        }
    }
}

@Composable
private fun AnalyticsCategoryRow(name: String, spent: Double, limit: Double) {
    val (color, emoji, _) = categoryVisuals(name)
    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text(emoji)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(name, color = primaryInk, fontWeight = FontWeight.SemiBold)
                Text("${formatCurrency(limit)} limit", color = mutedText, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .background(Color(0xFFE7EAF2), RoundedCornerShape(8.dp))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth((spent / limit).toFloat().coerceIn(0f, 1f))
                            .height(8.dp)
                            .background(color, RoundedCornerShape(8.dp))
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(formatCurrency(spent), color = primaryInk, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun AchievementCard(item: AchievementCardData) {
    DetailCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBubble(Icons.Filled.Info, item.color)
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(item.title, color = primaryInk, fontWeight = FontWeight.SemiBold, fontSize = 20.sp)
                Text(item.subtitle, color = mutedText)
            }
            Spacer(modifier = Modifier.weight(1f))
            if (item.unlocked) {
                Text("Unlocked", color = accentGreen, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun ProgressRow(leftText: String, rightText: String, progress: Float, color: Color) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(leftText, color = mutedText, fontSize = 12.sp)
        Text(rightText, color = mutedText, fontSize = 12.sp)
    }
    Spacer(modifier = Modifier.height(6.dp))
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(10.dp)
            .background(Color(0xFFE7EAF2), RoundedCornerShape(10.dp))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(progress)
                .height(10.dp)
                .background(color, RoundedCornerShape(10.dp))
        )
    }
}

@Composable
private fun DropdownSelector(
    label: String,
    selectedValue: String,
    options: List<String>,
    onSelected: (String) -> Unit,
    modifier: Modifier = Modifier,
    expanded: Boolean? = null,
    onExpandedChange: ((Boolean) -> Unit)? = null
) {
    var localExpanded by remember { mutableStateOf(false) }
    val isExpanded = expanded ?: localExpanded
    val setExpanded: (Boolean) -> Unit = onExpandedChange ?: { localExpanded = it }

    Box(modifier = modifier) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { setExpanded(true) },
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(label, color = mutedText, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(selectedValue, color = primaryInk)
                    Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = mutedText)
                }
            }
        }
        DropdownMenu(expanded = isExpanded, onDismissRequest = { setExpanded(false) }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onSelected(option)
                        setExpanded(false)
                    }
                )
            }
        }
    }
}

@Composable
private fun CleanTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    minLines: Int = 1
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        minLines = minLines,
        shape = RoundedCornerShape(14.dp)
    )
}

@Composable
private fun DatePickerField(label: String, value: String, onDateSelected: (String) -> Unit) {
    val context = LocalContext.current
    val initialDate = runCatching { LocalDate.parse(value) }.getOrElse { LocalDate.now() }
    SelectorField(
        label = label,
        value = value
    ) {
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val selected = LocalDate.of(year, month + 1, dayOfMonth)
                onDateSelected(selected.format(DateTimeFormatter.ISO_LOCAL_DATE))
            },
            initialDate.year,
            initialDate.monthValue - 1,
            initialDate.dayOfMonth
        ).show()
    }
}

@Composable
private fun TimePickerField(label: String, value: String, onTimeSelected: (String) -> Unit) {
    val context = LocalContext.current
    val hour = value.substringBefore(":").toIntOrNull() ?: 8
    val minute = value.substringAfter(":", "00").toIntOrNull() ?: 0
    SelectorField(label, value) {
        TimePickerDialog(
            context,
            { _, selectedHour, selectedMinute ->
                onTimeSelected(String.format("%02d:%02d", selectedHour, selectedMinute))
            },
            hour,
            minute,
            true
        ).show()
    }
}

@Composable
private fun SelectorField(label: String, value: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text(label, color = mutedText, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Text(value, color = primaryInk)
        }
    }
}

@Composable
private fun PrimaryDarkButton(
    label: String,
    icon: ImageVector? = null,
    onClick: () -> Unit,
    compact: Boolean = false
) {
    Button(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = if (compact) 14.dp else 18.dp, vertical = 12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = primaryInk, contentColor = Color.White),
        shape = RoundedCornerShape(12.dp)
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
        }
        Text(label)
    }
}

@Composable
private fun PrimarySoftButton(
    label: String,
    icon: ImageVector,
    compact: Boolean = false,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = if (compact) 14.dp else 18.dp, vertical = 12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = primaryInk),
        shape = RoundedCornerShape(12.dp)
    ) {
        Icon(icon, contentDescription = null)
        Spacer(modifier = Modifier.width(6.dp))
        Text(label)
    }
}

@Composable
private fun LogoBadge(size: androidx.compose.ui.unit.Dp) {
    Image(
        painter = painterResource(id = R.drawable.pennywise_logo),
        contentDescription = "PennyWise logo",
        modifier = Modifier
            .size(size)
            .clip(CircleShape),
        contentScale = ContentScale.Crop
    )
}

@Composable
private fun IconBubble(icon: ImageVector, color: Color) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(color.copy(alpha = 0.14f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = color)
    }
}

@Composable
private fun FlowGridLike(
    items: List<String>,
    itemContent: @Composable (String) -> Unit,
    trailingContent: (@Composable () -> Unit)? = null
) {
    val isCompact = isCompactScreen()
    if (isCompact) {
        items.forEach { item ->
            itemContent(item)
            Spacer(modifier = Modifier.height(16.dp))
        }
        trailingContent?.invoke()
    } else {
        for (chunk in items.chunked(2)) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
                chunk.forEach { item ->
                    Box(modifier = Modifier.weight(1f)) {
                        itemContent(item)
                    }
                }
                if (chunk.size == 1) {
                    Box(modifier = Modifier.weight(1f)) {}
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
        if (trailingContent != null) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
                Box(modifier = Modifier.weight(1f)) {}
                Box(modifier = Modifier.weight(1f)) {
                    trailingContent()
                }
            }
        }
    }
}

@Composable
private fun <T> FlowGridLike(
    items: List<T>,
    itemContent: @Composable (T) -> Unit
) {
    val isCompact = isCompactScreen()
    if (isCompact) {
        items.forEachIndexed { index, item ->
            itemContent(item)
            if (index != items.lastIndex) {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    } else {
        for (chunk in items.chunked(2)) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
                chunk.forEach { item ->
                    Box(modifier = Modifier.weight(1f)) {
                        itemContent(item)
                    }
                }
                if (chunk.size == 1) {
                    Box(modifier = Modifier.weight(1f)) {}
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun UriImage(photoUri: String?) {
    if (photoUri.isNullOrBlank()) return
    AndroidView(
        factory = { context ->
            ImageView(context).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
        },
        update = { imageView ->
            imageView.setImageURI(Uri.parse(photoUri))
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(16.dp))
    )
}

private data class MetricItem(
    val title: String,
    val value: String,
    val icon: ImageVector,
    val color: Color
)

private data class QuickAction(
    val title: String,
    val subtitle: String,
    val color: Color,
    val onClick: () -> Unit
)

private data class AchievementCardData(
    val title: String,
    val subtitle: String,
    val unlocked: Boolean,
    val color: Color
)

private fun categoryVisuals(name: String): Triple<Color, String, String> = when {
    name.contains("food", true) -> Triple(accentRed, "🍴", "Food & Dining")
    name.contains("transport", true) -> Triple(accentBlue, "🚗", "Cars")
    name.contains("shop", true) -> Triple(accentPurple, "🛍", "Shopping bag")
    name.contains("entertain", true) -> Triple(Color(0xFFF9BE45), "🎬", "Entertainment")
    name.contains("bill", true) -> Triple(accentPurple, "⚡", "Electric bill")
    name.contains("health", true) -> Triple(accentTeal, "💙", "Health Care")
    else -> Triple(accentBlue, "•", name)
}

private fun mergeCategoryNames(categories: List<Category>): List<String> {
    val defaults = BudgetViewModel.defaultCategoryNames()
    return (defaults + categories.map { it.name }).distinct()
}

private fun expenseTrendValues(expenses: List<ExpenseRecord>): List<Float> {
    if (expenses.isEmpty()) return emptyList()

    val totalsByDate = expenses
        .groupBy { it.date }
        .toSortedMap()
        .values
        .map { records -> records.sumOf { it.amount }.toFloat() }

    return if (totalsByDate.size == 1) {
        listOf(0f, totalsByDate.first())
    } else {
        totalsByDate
    }
}

@Composable
private fun isCompactScreen(): Boolean = LocalConfiguration.current.screenWidthDp < 700


private fun formatCurrency(amount: Double): String = "R%.2f".format(amount)
