package com.example.pennywisework

data class UserSession(
    val id: Int,
    val username: String
)

data class ExpenseRecord(
    val id: Int,
    val categoryId: Int,
    val categoryName: String,
    val amount: Double,
    val date: String,
    val startTime: String,
    val endTime: String,
    val description: String,
    val photoUri: String?
)

data class MonthlyGoal(
    val month: String,
    val minGoal: Double,
    val maxGoal: Double
)

data class CategoryTotal(
    val categoryName: String,
    val totalAmount: Double
)
