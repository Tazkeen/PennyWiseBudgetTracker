package com.example.pennywisework

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.util.Calendar

object NotificationHelper {
    private const val CHANNEL_ID = "pennywise_notifications"
    private const val CHANNEL_NAME = "PennyWise alerts"
    private const val DAILY_REMINDER_REQUEST_CODE = 1001
    private const val BUDGET_WARNING_ID = 2001
    private const val OVERSPENDING_ID = 2002
    private const val DAILY_REMINDER_ID = 2003

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Budget alerts and expense reminders"
            }

            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    fun scheduleDailyReminder(context: Context, enabled: Boolean) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, DailyReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            DAILY_REMINDER_REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (!enabled) {
            alarmManager.cancel(pendingIntent)
            return
        }

        val reminderTime = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 20)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (before(Calendar.getInstance())) {
                add(Calendar.DAY_OF_MONTH, 1)
            }
        }

        alarmManager.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            reminderTime.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            pendingIntent
        )
    }

    fun showBudgetWarning(context: Context, spent: Double, maxGoal: Double) {
        show(
            context = context,
            id = BUDGET_WARNING_ID,
            title = "Budget limit approaching",
            message = "You have spent ${formatCurrency(spent)} of your ${formatCurrency(maxGoal)} monthly budget."
        )
    }

    fun showOverspending(context: Context, spent: Double, maxGoal: Double) {
        show(
            context = context,
            id = OVERSPENDING_ID,
            title = "Budget exceeded",
            message = "You are over budget by ${formatCurrency(spent - maxGoal)}. Review your expenses."
        )
    }

    fun showDailyReminder(context: Context) {
        show(
            context = context,
            id = DAILY_REMINDER_ID,
            title = "Log today's expenses",
            message = "Add any spending from today to keep your budget accurate."
        )
    }

    private fun show(context: Context, id: Int, title: String, message: String) {
        ensureChannel(context)

        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            id,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        NotificationManagerCompat.from(context).notify(id, notification)
    }

    private fun formatCurrency(amount: Double): String = "R%.2f".format(amount.coerceAtLeast(0.0))
}

class DailyReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("budget_session", Context.MODE_PRIVATE)
        if (prefs.getBoolean("notifications_enabled", false)) {
            NotificationHelper.showDailyReminder(context)
        }
    }
}
