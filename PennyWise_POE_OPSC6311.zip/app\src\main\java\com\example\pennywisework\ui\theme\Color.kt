package com.example.pennywisework.ui.theme

import androidx.compose.ui.graphics.Color

val PennyPrimary = Color(0xFF5C4BFF)
val PennySecondary = Color(0xFF7D8AB3)
val PennyTertiary = Color(0xFF9B4DFF)
val PennyBackground = Color(0xFFF1F4FF)
val PennySurface = Color(0xFFFFFFFF)
val PennySurfaceVariant = Color(0xFFEAE8FF)
val PennyOnPrimary = Color(0xFFFFFFFF)
val PennyOnSurface = Color(0xFF05031A)
val PennyOnBackground = Color(0xFF05031A)
