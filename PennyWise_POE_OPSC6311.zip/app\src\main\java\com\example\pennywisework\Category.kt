package com.example.pennywisework

data class Category(
    val id: Int,
    val userId: Int = 0,
    val name: String
)
